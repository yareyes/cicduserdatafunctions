from .metadata_generator import generate_function_metadata

generate_function_metadata()
