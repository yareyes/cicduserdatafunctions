# flake8: noqa: I003

from azure.eventgrid import EventGridPublisherClient, EventGridConsumerClient
from fabric.functions.fabric_item import FabricItem
from fabric.functions.providers.base_fabricitem_provider import BaseFabricItemProvider


def get_eventgrid_client(item: FabricItem, endpoint: str, namespace_topic: str = None) -> EventGridPublisherClient:
    """Create an EventGridPublisherClient from a FabricItem and endpoint URL.

    Uses the access token from the FabricItem to authenticate against the
    provided EventGrid topic/namespace endpoint.

    Args:
        item: The FabricItem containing the access token (from a generic_connection
              decorator with audienceType="EventGrid").
        endpoint: The EventGrid topic or namespace endpoint URL.
        namespace_topic: The namespace topic name. Required for Event Grid
              Namespaces; omit for Event Grid Basic.

    Returns:
        An authenticated EventGridPublisherClient ready to publish events.

    Example:
        .. code-block:: python

            import fabric.functions as fn
            from fabric.functions.eventgrid import get_eventgrid_client

            udf = fn.UserDataFunctions()

            @udf.generic_connection(argName="events", audienceType="EventGrid")
            @udf.function()
            def my_function(events: fn.FabricItem) -> None:
                # For Event Grid Namespaces:
                client = get_eventgrid_client(events, "https://my-ns.westus2-1.eventgrid.azure.net", namespace_topic="my-topic")
                # For Event Grid Basic:
                client = get_eventgrid_client(events, "https://my-topic.westus2-1.eventgrid.azure.net/api/events")
                client.send([CloudEvent(source="myapp", type="order.created", data={"id": "123"})])
    """
    credential = item.get_access_token()
    if namespace_topic:
        return EventGridPublisherClient(endpoint=endpoint, credential=credential, namespace_topic=namespace_topic)
    return EventGridPublisherClient(endpoint=endpoint, credential=credential)


def get_eventgrid_consumer_client(item: FabricItem, endpoint: str, namespace_topic: str, subscription: str) -> EventGridConsumerClient:
    """Create an EventGridConsumerClient from a FabricItem and endpoint URL.

    Uses the access token from the FabricItem to authenticate against the
    provided Event Grid Namespace endpoint.  The consumer client supports
    pull-based delivery: receive, acknowledge, release, and reject events.

    Note: Only works with Event Grid Namespaces (not Basic/Custom Topics).

    Args:
        item: The FabricItem containing the access token (from a generic_connection
              decorator with audienceType="EventGrid").
        endpoint: The Event Grid Namespace endpoint URL.
        namespace_topic: The namespace topic name (required).
        subscription: The subscription name on the topic (required).

    Returns:
        An authenticated EventGridConsumerClient.

    Example:
        .. code-block:: python

            import fabric.functions as fn
            from fabric.functions.eventgrid import get_eventgrid_consumer_client

            udf = fn.UserDataFunctions()

            @udf.generic_connection(argName="eg", audienceType="EventGrid")
            @udf.function()
            def process_events(eg: fn.FabricItem) -> list[dict]:
                client = get_eventgrid_consumer_client(
                    eg,
                    endpoint="https://my-ns.westus2-1.eventgrid.azure.net",
                    namespace_topic="orders-topic",
                    subscription="my-sub"
                )
                response = client.receive(max_events=5)
                results = []
                tokens = []
                for detail in response.value:
                    results.append({"type": detail.event.type, "data": detail.event.data})
                    tokens.append(detail.broker_properties.lock_token)
                if tokens:
                    client.acknowledge(lock_tokens=tokens)
                return results
    """
    credential = item.get_access_token()
    return EventGridConsumerClient(endpoint=endpoint, credential=credential,
                                   namespace_topic=namespace_topic, subscription=subscription)


class EventGridPublisherProvider(BaseFabricItemProvider):
    """Provider for automatic EventGridPublisherClient creation via decorator.

    Allows using EventGridPublisherClient as a type annotation with the
    generic_connection decorator:

        @udf.generic_connection(argName="eg", audienceType="EventGrid",
                                eventgrid_endpoint="https://...",
                                namespace_topic="my-topic")
        @udf.function()
        def my_function(eg: EventGridPublisherClient) -> None:
            eg.send([...])
    """

    def __init__(self):
        pass

    def create(self, item: FabricItem, req=None, **kwargs):
        endpoint = kwargs.get("eventgrid_endpoint")
        if endpoint is None:
            raise ValueError("EventGrid endpoint URL must be provided via 'eventgrid_endpoint' kwarg")
        namespace_topic = kwargs.get("namespace_topic")
        return get_eventgrid_client(item, endpoint, namespace_topic=namespace_topic)


class EventGridConsumerProvider(BaseFabricItemProvider):
    """Provider for automatic EventGridConsumerClient creation via decorator.

    Allows using EventGridConsumerClient as a type annotation with the
    generic_connection decorator:

        @udf.generic_connection(argName="eg", audienceType="EventGrid",
                                eventgrid_endpoint="https://...",
                                namespace_topic="my-topic")
        @udf.function()
        def my_function(eg: EventGridConsumerClient) -> None:
            response = eg.receive(subscription="my-sub", max_events=5)
            ...
    """

    def __init__(self):
        pass

    def create(self, item: FabricItem, req=None, **kwargs):
        endpoint = kwargs.get("eventgrid_endpoint")
        if endpoint is None:
            raise ValueError("EventGrid endpoint URL must be provided via 'eventgrid_endpoint' kwarg")
        namespace_topic = kwargs.get("namespace_topic")
        if namespace_topic is None:
            raise ValueError("namespace_topic must be provided for EventGridConsumerClient")
        subscription = kwargs.get("subscription")
        if subscription is None:
            raise ValueError("subscription must be provided for EventGridConsumerClient")
        return get_eventgrid_consumer_client(item, endpoint, namespace_topic=namespace_topic, subscription=subscription)
