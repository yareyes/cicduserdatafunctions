from fabric.functions.user_data_functions import UserDataFunctions
from azure.eventgrid import EventGridPublisherClient, EventGridConsumerClient
from .eventgrid_provider import EventGridPublisherProvider, EventGridConsumerProvider


def use_eventgrid(udf: UserDataFunctions):
    udf.register_provider(EventGridPublisherClient, EventGridPublisherProvider)
    udf.register_provider(EventGridConsumerClient, EventGridConsumerProvider)