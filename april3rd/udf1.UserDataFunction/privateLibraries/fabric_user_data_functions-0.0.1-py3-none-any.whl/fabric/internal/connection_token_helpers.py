# flake8: noqa: I900
import json
import logging

from fabric.functions.fabric_item import FabricItem
from fabric.functions.udf_exception import UserDataFunctionInternalError
from fabric.internal.decorators.constants import HeaderConstants, MWCBaseURL

logger = logging.getLogger(__name__)


class ConnectionTokenHelpers:
    """Pure static helpers for parsing and applying connection tokens.

    These methods are stateless and handle all the data transformation
    between the raw workload endpoint response and the FabricItem
    instances that the user's function receives.
    """

    @staticmethod
    def parse_context_header(req) -> dict:
        """Extract and parse the JSON context header from the HTTP request.

        The header contains the CapacityId, ArtifactId, and ExecutingUser
        (with TenantId) needed to build the workload endpoint URL.

        Raises UserDataFunctionInternalError if the header is missing or
        contains invalid JSON.
        """
        raw = req.headers.get(HeaderConstants.UDF_CONTEXT)
        if not raw:
            raise UserDataFunctionInternalError(
                f"Missing required header '{HeaderConstants.UDF_CONTEXT}' for token acquisition.")
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError) as e:
            raise UserDataFunctionInternalError(
                f"Invalid JSON in header '{HeaderConstants.UDF_CONTEXT}': {e}") from e

    @staticmethod
    def build_workload_url(context: dict, function_name: str) -> str:
        """Build the Fabric workload endpoint URL from the context header.

        The URL follows the pattern (sample for edog environment):
          https://<capacityHex>.pbidedicated.windows-int.net/webapi/capacities/<capacityId>
            /workloads/FuncSet/FuncSetService/automatic
            /userDataFunctions/<artifactId>
            /connections/artifactTenantId/<tenantId>
            /<functionName>

        The capacity hex subdomain is the capacityId with dashes removed.
        All required fields are read from the ItemContext nested object.
        Accepts both PascalCase and camelCase field names.

        Raises UserDataFunctionInternalError if any required field is missing.
        """
        item_context = context.get("ItemContext") or context.get("itemContext") or {}
        capacity_id = item_context.get("CapacityId") or item_context.get("capacityId")
        artifact_id = item_context.get("ArtifactId") or item_context.get("artifactId")
        artifact_tenant_id = item_context.get("TenantId") or item_context.get("tenantId")

        if not all([capacity_id, artifact_id, artifact_tenant_id]):
            raise UserDataFunctionInternalError(
                f"Header '{HeaderConstants.UDF_CONTEXT}' missing required fields "
                f"(ItemContext.CapacityId, ItemContext.ArtifactId, ItemContext.TenantId).")

        capacity_hex = capacity_id.replace("-", "")
        base_host = ConnectionTokenHelpers._resolve_base_host(
            capacity_hex, item_context.get("Environment") or item_context.get("environment") or ""
        )
        return (
            f"https://{base_host}/webapi/capacities/{capacity_id}"
            f"/workloads/FuncSet/FuncSetService/automatic"
            f"/userDataFunctions/{artifact_id}"
            f"/connections/artifactTenantId/{artifact_tenant_id}"
            f"/{function_name}"
        )

    @staticmethod
    def _resolve_base_host(capacity_hex: str, environment: str) -> str:
        """Resolve the workload endpoint host based on the environment.

        Uses the ENVIRONMENT_HOSTS mapping from WorkloadEndpointConstants.
        Known environments (e.g. 'edog') use their specific host template;
        all others fall back to DEFAULT_HOST.
        """
        template = MWCBaseURL.ENVIRONMENT_HOSTS.get(
            environment.lower(),
            MWCBaseURL.DEFAULT_HOST
        )
        return template.format(capacity_hex=capacity_hex, environment=environment)

    @staticmethod
    def connections_need_tokens(fabric_items: list) -> bool:
        """Determine whether token acquisition is needed.

        Returns True if there are FabricItem instances and none of them
        have an AccessToken in any endpoint.  Returns False when there
        are no items or when at least one item already has a token
        (indicating the host extension resolved tokens successfully).
        """
        items = [v for v in fabric_items if isinstance(v, FabricItem)]
        if not items:
            return False

        for item in items:
            for endpoint_info in item.endpoints.values():
                if isinstance(endpoint_info, dict) and endpoint_info.get("AccessToken"):
                    return False
        return True

    @staticmethod
    def parse_token_response(token_response: list) -> tuple:
        """Parse the workload endpoint response into two lookup dicts.

        The response is a flat JSON array with two kinds of entries:

        Alias-based (for Lakehouse, SQL, VL connections):
            {"alias": "LH1_FileEndpoint", "connectionString": "...", "token": "..."}
          The alias is split on the last underscore: "LH1" is the item alias
          and "FileEndpoint" (lowercased) is the endpoint type key.

        Audience-based (for generic connection types like CosmosDB, KeyVault):
            {"audience": "KeyVault", "token": "..."}

        Returns:
            (alias_dict, audience_dict) where:
            - alias_dict:    { alias_name: { endpoint_type_lower: { "token": ..., "connectionString": ... } } }
            - audience_dict: { audience_lower: { "token": ... } }
        """
        alias_parsed = {}
        audience_parsed = {}

        for entry in token_response:
            token = entry.get("token")
            audience = entry.get("audience")
            raw_alias = entry.get("alias", "")

            if audience:
                audience_parsed[audience.lower()] = {"token": token}
                continue

            if not raw_alias:
                logger.warning("[ConnectionTokenProvider] Entry has neither alias nor audience, skipping")
                continue

            connection_string = entry.get("connectionString")

            last_underscore = raw_alias.rfind("_")
            if last_underscore <= 0:
                logger.warning("[ConnectionTokenProvider] Could not parse endpoint type from alias "
                               "(no underscore found): %s", raw_alias)
                continue

            item_alias = raw_alias[:last_underscore]
            endpoint_key = raw_alias[last_underscore + 1:].lower()

            if item_alias not in alias_parsed:
                alias_parsed[item_alias] = {}

            alias_parsed[item_alias][endpoint_key] = {
                "token": token,
                "connectionString": connection_string,
            }

        return alias_parsed, audience_parsed

    @staticmethod
    def rebuild_stub_items(kwargs: dict, fabric_item_params: list,
                           alias_response: dict, audience_response: dict,
                           param_metadata: dict):
        """Replace stub FabricItems with fully-typed instances using workload data.

        When the host extension can't resolve a connection it sends an
        ErrorMessage.  decode() turns that into a stub FabricItem with
        an empty endpoints dict.  This method finds those stubs and
        reconstructs them:

        - Alias-based stubs: endpoints are built from the alias_response
          dict and FabricItemConverter.parseType() creates the correct
          subclass (FabricSqlConnection, FabricLakehouseClient, etc.).
        - Audience-based stubs: a base FabricItem is created with the
          token from the audience_response dict.

        The reconstructed item replaces the stub in kwargs so downstream
        providers and the user's function receive a complete object.
        """
        from fabric.internal.item_binding import FabricItemConverter

        for p in fabric_item_params:
            item = kwargs.get(p.name)
            if not isinstance(item, FabricItem):
                continue
            if item.endpoints:
                continue

            alias = item.alias_name
            meta = param_metadata.get(p.name, {})
            audience_type = meta.get("audienceType", "")

            if alias and alias in alias_response:
                endpoints = {}
                for endpoint_key, entry in alias_response[alias].items():
                    endpoints[endpoint_key] = {
                        "ConnectionString": entry.get("connectionString", ""),
                        "AccessToken": entry.get("token", ""),
                    }

                body = {"AliasName": alias, "Endpoints": {k: v for k, v in endpoints.items()}}
                new_item = FabricItemConverter.parseType(body)
                kwargs[p.name] = new_item

            elif audience_type and audience_type.lower() in audience_response:
                token = audience_response[audience_type.lower()].get("token", "")
                endpoints = {audience_type.lower(): {"AccessToken": token}}
                new_item = FabricItem(alias_name=alias or audience_type, endpoints=endpoints)
                kwargs[p.name] = new_item
            else:
                logger.warning("[ConnectionTokenProvider] Could not rebuild stub for param=%s alias=%s",
                               p.name, alias)

    @staticmethod
    def apply_tokens_to_items(fabric_items: list, alias_response: dict,
                              audience_response: dict, param_metadata: dict):
        """Patch tokens and connection strings into existing FabricItem endpoints.

        Unlike rebuild_stub_items (which handles items with *empty* endpoints),
        this method handles items whose endpoints were already populated by
        the host extension but are missing AccessTokens or ConnectionStrings.

        For alias-based items, each endpoint is matched by its key (e.g.
        "sqlendpoint", "fileendpoint") against the alias_response dict.

        For audience-based items (generic connections), the audienceType from
        param_metadata is used to look up the token in audience_response, and
        the token is applied to all endpoints on the item.
        """
        for param_name, item in fabric_items:
            if not isinstance(item, FabricItem):
                continue

            alias = item.alias_name

            if alias in alias_response:
                alias_data = alias_response[alias]
                for endpoint_key, endpoint_info in item.endpoints.items():
                    if not isinstance(endpoint_info, dict):
                        continue
                    if endpoint_key not in alias_data:
                        continue

                    entry = alias_data[endpoint_key]

                    token = entry.get("token")
                    if token:
                        endpoint_info["AccessToken"] = token

                    connection_string = entry.get("connectionString")
                    if connection_string and not endpoint_info.get("ConnectionString"):
                        endpoint_info["ConnectionString"] = connection_string
                continue

            meta = param_metadata.get(param_name, {})
            audience_type = meta.get("audienceType", "")
            if audience_type and audience_type.lower() in audience_response:
                token = audience_response[audience_type.lower()].get("token")
                if token:
                    for endpoint_info in item.endpoints.values():
                        if isinstance(endpoint_info, dict):
                            endpoint_info["AccessToken"] = token
                continue

    @staticmethod
    def raise_for_unresolved_stubs(kwargs: dict, fabric_item_params: list):
        """Validate that no FabricItem stubs remain with empty endpoints.

        Called after all token acquisition and patching is complete.  If a
        stub still has no endpoints, it means neither the host extension nor
        the workload endpoint could resolve the connection.  This raises a
        clear UserDataFunctionInternalError (including the original host
        error message when available) instead of letting the user's function
        run with a broken FabricItem that would cause confusing runtime
        errors like StopIteration or KeyError.
        """
        for p in fabric_item_params:
            item = kwargs.get(p.name)
            if isinstance(item, FabricItem) and not item.endpoints:
                host_error = getattr(item, '_host_error', None)
                if host_error:
                    raise UserDataFunctionInternalError(
                        f"Connection for '{p.name}' could not be resolved. "
                        f"Host error: {host_error}")
                raise UserDataFunctionInternalError(
                    f"Connection for '{p.name}' has no endpoints and could not be resolved.")
