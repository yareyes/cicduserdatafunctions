# flake8: noqa: I900
import logging
import time
import requests
from azure.identity import ManagedIdentityCredential

from fabric.functions.udf_exception import UserDataFunctionInternalError
from fabric.internal.connection_token_helpers import ConnectionTokenHelpers

logger = logging.getLogger(__name__)

_FABRIC_UDF_SCOPE = "https://analysis.windows-int.net/powerbi/api"


class ConnectionTokenProvider:
    """Orchestrates a two-step token acquisition flow for Fabric connections.

    When the host extension cannot resolve connection tokens (or when tokens
    are intentionally omitted), this provider fills them in:

      Step A – Acquire a Managed-Identity (MSI) token scoped to the Fabric
               UDF API.  The credential is lazily created and reused across
               invocations.
      Step B – Call a Fabric UDF workload endpoint (authenticated with the MSI
               token) that returns the real per-connection AccessTokens and
               ConnectionStrings for every connection the function needs.

    Instance state is limited to the cached ManagedIdentityCredential; all
    parsing, patching, and validation logic lives in ConnectionTokenHelpers.
    """

    def __init__(self):
        self._credential = None

    def _get_msi_token(self) -> str:
        """Acquire an MSI token for the Fabric UDF scope.

        The ManagedIdentityCredential is created once and reused.  The token
        is used as a Bearer token when calling the workload endpoint.
        """
        if self._credential is None:
            self._credential = ManagedIdentityCredential()
        start = time.monotonic()
        token = self._credential.get_token(_FABRIC_UDF_SCOPE)
        elapsed_ms = (time.monotonic() - start) * 1000
        logger.info("[ConnectionTokenProvider] MSI token acquired (elapsed=%.0fms)", elapsed_ms)
        return token.token

    def _fetch_connection_tokens(self, url: str, msi_token: str) -> list:
        """Call the Fabric workload endpoint to retrieve connection tokens.

        Sends a GET request authenticated with the MSI token.  The endpoint
        returns a JSON array containing entries for every connection the
        function declared — either alias-based (Lakehouse, SQL, VL) or
        audience-based (CosmosDB, KeyVault, etc.).

        Raises UserDataFunctionInternalError on non-2xx responses.
        """
        headers = {"Authorization": f"Bearer {msi_token}"}
        start = time.monotonic()
        response = requests.get(url, headers=headers, timeout=30)
        elapsed_ms = (time.monotonic() - start) * 1000
        logger.info("[ConnectionTokenProvider] Workload response status=%d (elapsed=%.0fms)",
                    response.status_code, elapsed_ms)

        if not response.ok:
            raise UserDataFunctionInternalError(
                f"Failed to fetch connection tokens from workload endpoint. "
                f"Status: {response.status_code}, Reason: {response.reason}")

        return response.json()

    def ensure_tokens(self, req, kwargs: dict, fabric_item_params: list, func_name: str,
                       provider_metadata=None):
        """Main entry point — ensure every FabricItem in *kwargs* has valid tokens.

        This method is called before the user's function runs.  It:
          1. Checks whether any FabricItem is missing an AccessToken.  If all
             items already have tokens (host extension resolved them), it
             returns immediately — no MSI or workload calls are made.
          2. Acquires an MSI token and calls the workload endpoint to get the
             real tokens for every connection.
          3. Rebuilds any "stub" FabricItems (created by decode() when the
             host extension returned an error) into the correct subclass
             (FabricSqlConnection, FabricLakehouseClient, etc.) using the
             workload response data.
          4. Patches AccessTokens and ConnectionStrings into items that
             already had endpoints but were missing tokens.
          5. Validates that no stubs remain unresolved.  If a connection
             could not be resolved by either the host or the workload
             endpoint, a clear error is raised instead of letting the user's
             function run with broken FabricItem instances.

        Args:
            req: The HttpRequest (provides the context header with capacity/
                 artifact/tenant IDs).
            kwargs: The function kwargs dict containing FabricItem instances.
            fabric_item_params: Parameter definitions for fabric item args.
            func_name: The user function name (used in the workload URL).
            provider_metadata: ProviderMetadata instance (supplies audienceType
                               for generic connection matching).
        """
        if not fabric_item_params:
            return

        items = [kwargs.get(p.name) for p in fabric_item_params
                 if kwargs.get(p.name) is not None]
        if not ConnectionTokenHelpers.connections_need_tokens(items):
            return

        try:
            msi_token = self._get_msi_token()
        except Exception as e:
            logger.error("[ConnectionTokenProvider] Failed to acquire MSI token: %s", e)
            ConnectionTokenHelpers.raise_for_unresolved_stubs(kwargs, fabric_item_params)
            return

        try:
            context = ConnectionTokenHelpers.parse_context_header(req)
            url = ConnectionTokenHelpers.build_workload_url(context, func_name)
        except Exception as e:
            logger.error("[ConnectionTokenProvider] Failed to build workload URL: %s", e)
            ConnectionTokenHelpers.raise_for_unresolved_stubs(kwargs, fabric_item_params)
            return

        try:
            token_response = self._fetch_connection_tokens(url, msi_token)
        except Exception as e:
            logger.error("[ConnectionTokenProvider] Failed to fetch connection tokens: %s", e)
            ConnectionTokenHelpers.raise_for_unresolved_stubs(kwargs, fabric_item_params)
            return

        alias_parsed, audience_parsed = ConnectionTokenHelpers.parse_token_response(token_response)

        # Build list of (param_name, item) tuples and per-param metadata
        items = [(p.name, kwargs.get(p.name)) for p in fabric_item_params
                 if kwargs.get(p.name) is not None]
        param_meta = {}
        if provider_metadata:
            for p in fabric_item_params:
                param_meta[p.name] = provider_metadata.get_kwargs(func_name, p.name)

        if items:
            ConnectionTokenHelpers.rebuild_stub_items(kwargs, fabric_item_params, alias_parsed, audience_parsed, param_meta)

            items = [(p.name, kwargs.get(p.name)) for p in fabric_item_params
                     if kwargs.get(p.name) is not None]
            ConnectionTokenHelpers.apply_tokens_to_items(items, alias_parsed, audience_parsed, param_meta)

        ConnectionTokenHelpers.raise_for_unresolved_stubs(kwargs, fabric_item_params)
